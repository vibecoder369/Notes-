package com.notes.privatenotes

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
