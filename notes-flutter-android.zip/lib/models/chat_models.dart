enum RoomConnectionStatus {
  disconnected,
  connecting,
  waitingForPeer,
  connected,
  offlineError,
}

enum MessageDeliveryStatus {
  sending,
  sent,
  failed,
}

class RoomSession {
  const RoomSession({
    required this.roomId,
    required this.isCreator,
    required this.joinedAt,
    required this.inviteUsed,
    this.inviteCode,
    this.peerPublicKey,
  });

  final String roomId;
  final bool isCreator;
  final DateTime joinedAt;
  final bool inviteUsed;
  final String? inviteCode;
  final String? peerPublicKey;

  bool get hasPeer => peerPublicKey != null && peerPublicKey!.isNotEmpty;

  RoomSession copyWith({
    String? roomId,
    bool? isCreator,
    DateTime? joinedAt,
    bool? inviteUsed,
    String? inviteCode,
    bool clearInviteCode = false,
    String? peerPublicKey,
    bool clearPeerPublicKey = false,
  }) {
    return RoomSession(
      roomId: roomId ?? this.roomId,
      isCreator: isCreator ?? this.isCreator,
      joinedAt: joinedAt ?? this.joinedAt,
      inviteUsed: inviteUsed ?? this.inviteUsed,
      inviteCode: clearInviteCode ? null : (inviteCode ?? this.inviteCode),
      peerPublicKey:
          clearPeerPublicKey ? null : (peerPublicKey ?? this.peerPublicKey),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'roomId': roomId,
      'isCreator': isCreator,
      'joinedAt': joinedAt.toUtc().toIso8601String(),
      'inviteUsed': inviteUsed,
      'inviteCode': inviteCode,
      'peerPublicKey': peerPublicKey,
    };
  }

  factory RoomSession.fromJson(Map<String, dynamic> json) {
    return RoomSession(
      roomId: json['roomId'] as String,
      isCreator: (json['isCreator'] as bool?) ?? false,
      joinedAt: DateTime.parse(json['joinedAt'] as String).toLocal(),
      inviteUsed: (json['inviteUsed'] as bool?) ?? false,
      inviteCode: json['inviteCode'] as String?,
      peerPublicKey: json['peerPublicKey'] as String?,
    );
  }
}

class ChatMessage {
  const ChatMessage({
    required this.id,
    required this.roomId,
    required this.authorId,
    required this.plaintext,
    required this.createdAt,
    required this.isMine,
    required this.status,
    this.decryptionError,
  });

  final String id;
  final String roomId;
  final String authorId;
  final String plaintext;
  final DateTime createdAt;
  final bool isMine;
  final MessageDeliveryStatus status;
  final String? decryptionError;

  ChatMessage copyWith({
    String? id,
    String? roomId,
    String? authorId,
    String? plaintext,
    DateTime? createdAt,
    bool? isMine,
    MessageDeliveryStatus? status,
    String? decryptionError,
  }) {
    return ChatMessage(
      id: id ?? this.id,
      roomId: roomId ?? this.roomId,
      authorId: authorId ?? this.authorId,
      plaintext: plaintext ?? this.plaintext,
      createdAt: createdAt ?? this.createdAt,
      isMine: isMine ?? this.isMine,
      status: status ?? this.status,
      decryptionError: decryptionError ?? this.decryptionError,
    );
  }
}

class UnsentMessageDraft {
  const UnsentMessageDraft({
    required this.localId,
    required this.plaintext,
    required this.createdAt,
  });

  final String localId;
  final String plaintext;
  final DateTime createdAt;

  Map<String, dynamic> toJson() {
    return {
      'localId': localId,
      'plaintext': plaintext,
      'createdAt': createdAt.toUtc().toIso8601String(),
    };
  }

  factory UnsentMessageDraft.fromJson(Map<String, dynamic> json) {
    return UnsentMessageDraft(
      localId: json['localId'] as String,
      plaintext: json['plaintext'] as String,
      createdAt: DateTime.parse(json['createdAt'] as String).toLocal(),
    );
  }
}
