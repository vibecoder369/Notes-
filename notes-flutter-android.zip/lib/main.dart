import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'core/config/supabase_config.dart';
import 'core/theme/app_theme.dart';
import 'screens/home_screen.dart';
import 'services/crypto_service.dart';
import 'services/local_notes_repository.dart';
import 'services/secure_prefs_repository.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: AppTheme.pureBlack,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: AppTheme.pureBlack,
      systemNavigationBarIconBrightness: Brightness.light,
    ),
  );

  await SupabaseConfig.initializeIfConfigured();

  final notesRepository = LocalNotesRepository();
  final securePrefs = SecurePrefsRepository();
  final cryptoService = CryptoService();

  runApp(
    NotesApp(
      notesRepository: notesRepository,
      securePrefs: securePrefs,
      cryptoService: cryptoService,
    ),
  );
}

class NotesApp extends StatelessWidget {
  const NotesApp({
    super.key,
    required this.notesRepository,
    required this.securePrefs,
    required this.cryptoService,
  });

  final LocalNotesRepository notesRepository;
  final SecurePrefsRepository securePrefs;
  final CryptoService cryptoService;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Notes',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.darkTheme(),
      home: HomeScreen(
        notesRepository: notesRepository,
        securePrefs: securePrefs,
        cryptoService: cryptoService,
      ),
    );
  }
}
