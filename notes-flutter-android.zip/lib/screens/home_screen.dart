import 'dart:async';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../core/theme/app_theme.dart';
import '../models/note.dart';
import '../services/crypto_service.dart';
import '../services/local_notes_repository.dart';
import '../services/secure_prefs_repository.dart';
import 'note_editor_screen.dart';
import 'private_chat_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({
    super.key,
    required this.notesRepository,
    required this.securePrefs,
    required this.cryptoService,
  });

  final LocalNotesRepository notesRepository;
  final SecurePrefsRepository securePrefs;
  final CryptoService cryptoService;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final TextEditingController _searchController = TextEditingController();
  final FocusNode _searchFocusNode = FocusNode();

  List<Note> _allNotes = [];
  List<Note> _filteredNotes = [];
  bool _isLoading = true;
  String _searchQuery = '';

  @override
  void initState() {
    super.initState();
    unawaited(_initializeScreen());
  }

  Future<void> _initializeScreen() async {
    final notes = await widget.notesRepository.loadNotes();
    if (!mounted) return;
    setState(() {
      _allNotes = notes;
      _filteredNotes = notes;
      _isLoading = false;
    });

    final setupDone = await widget.securePrefs.isInitialSetupCompleted();
    if (!setupDone && mounted) {
      await _showInitialSetupDialog();
    }
  }

  Future<void> _showInitialSetupDialog() async {
    final keywordController = TextEditingController();
    bool obscure = true;

    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              title: const Text(
                'Initial Setup',
                style: TextStyle(
                  color: AppTheme.textPrimary,
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                ),
              ),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Set an optional private keyword. Entering this exact keyword in the Notes search bar opens private messaging. You can change it later in Settings.',
                    style: TextStyle(
                      color: AppTheme.textSecondary,
                      fontSize: 13.5,
                      height: 1.45,
                    ),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: keywordController,
                    obscureText: obscure,
                    autocorrect: false,
                    enableSuggestions: false,
                    style: const TextStyle(color: AppTheme.textPrimary),
                    decoration: InputDecoration(
                      hintText: 'Enter secret keyword',
                      suffixIcon: IconButton(
                        onPressed: () => setDialogState(() => obscure = !obscure),
                        icon: Icon(
                          obscure ? Icons.visibility_outlined : Icons.visibility_off_outlined,
                          color: AppTheme.textSecondary,
                          size: 20,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () async {
                    await widget.securePrefs.markInitialSetupCompleted();
                    if (dialogContext.mounted) {
                      Navigator.of(dialogContext).pop();
                    }
                  },
                  child: const Text(
                    'Skip for now',
                    style: TextStyle(color: AppTheme.textSecondary),
                  ),
                ),
                FilledButton(
                  style: FilledButton.styleFrom(
                    backgroundColor: AppTheme.accent,
                    foregroundColor: AppTheme.pureBlack,
                  ),
                  onPressed: () async {
                    final kw = keywordController.text.trim();
                    if (kw.isNotEmpty) {
                      await widget.securePrefs.setSecretKeyword(kw);
                    } else {
                      await widget.securePrefs.markInitialSetupCompleted();
                    }
                    if (dialogContext.mounted) {
                      Navigator.of(dialogContext).pop();
                    }
                  },
                  child: const Text('Save'),
                ),
              ],
            );
          },
        );
      },
    );

    keywordController.dispose();
  }

  void _onSearchChanged(String value) {
    setState(() {
      _searchQuery = value;
      _filteredNotes = widget.notesRepository.searchNotes(_allNotes, value);
    });
  }

  Future<void> _onSearchSubmitted(String value) async {
    final isSecretMatch = await widget.securePrefs.matchesSecretKeyword(value);
    if (!mounted) return;

    if (isSecretMatch) {
      _searchController.clear();
      _searchFocusNode.unfocus();
      setState(() {
        _searchQuery = '';
        _filteredNotes = _allNotes;
      });

      await Navigator.of(context).push(
        MaterialPageRoute<void>(
          builder: (_) => PrivateChatScreen(
            securePrefs: widget.securePrefs,
            cryptoService: widget.cryptoService,
          ),
        ),
      );
      return;
    }

    setState(() {
      _searchQuery = value;
      _filteredNotes = widget.notesRepository.searchNotes(_allNotes, value);
    });
  }

  Future<void> _openEditor({Note? note}) async {
    final target = note ?? widget.notesRepository.createEmptyNote();
    final isNew = note == null;

    final updated = await Navigator.of(context).push<bool>(
      MaterialPageRoute<bool>(
        builder: (_) => NoteEditorScreen(
          note: target,
          isNew: isNew,
          notesRepository: widget.notesRepository,
        ),
      ),
    );

    if (updated == true) {
      final refreshed = await widget.notesRepository.loadNotes();
      if (!mounted) return;
      setState(() {
        _allNotes = refreshed;
        _filteredNotes = widget.notesRepository.searchNotes(refreshed, _searchQuery);
      });
    }
  }

  Future<void> _openSettings() async {
    await Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => SettingsScreen(securePrefs: widget.securePrefs),
      ),
    );
  }

  String _formatTimestamp(DateTime dt) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final date = DateTime(dt.year, dt.month, dt.day);

    if (date == today) {
      return 'Today, ${DateFormat.jm().format(dt)}';
    }
    if (today.difference(date).inDays == 1) {
      return 'Yesterday, ${DateFormat.jm().format(dt)}';
    }
    return DateFormat('MMM d, y').format(dt);
  }

  @override
  void dispose() {
    _searchController.dispose();
    _searchFocusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Notes'),
        actions: [
          IconButton(
            tooltip: 'Settings',
            onPressed: _openSettings,
            icon: const Icon(Icons.settings_outlined, color: AppTheme.textSecondary),
          ),
          const SizedBox(width: 4),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        tooltip: 'New note',
        onPressed: () => unawaited(_openEditor()),
        child: const Icon(Icons.add, size: 26),
      ),
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
              child: TextField(
                controller: _searchController,
                focusNode: _searchFocusNode,
                textInputAction: TextInputAction.search,
                onChanged: _onSearchChanged,
                onSubmitted: (val) => unawaited(_onSearchSubmitted(val)),
                style: const TextStyle(color: AppTheme.textPrimary, fontSize: 15),
                decoration: InputDecoration(
                  hintText: 'Search notes',
                  prefixIcon: const Icon(
                    Icons.search,
                    color: AppTheme.textMuted,
                    size: 20,
                  ),
                  suffixIcon: _searchQuery.isEmpty
                      ? null
                      : Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(
                              tooltip: 'Search',
                              onPressed: () => unawaited(
                                _onSearchSubmitted(_searchController.text),
                              ),
                              icon: const Icon(
                                Icons.arrow_forward,
                                color: AppTheme.textSecondary,
                                size: 18,
                              ),
                            ),
                            IconButton(
                              tooltip: 'Clear search',
                              onPressed: () {
                                _searchController.clear();
                                _onSearchChanged('');
                              },
                              icon: const Icon(
                                Icons.close,
                                color: AppTheme.textMuted,
                                size: 18,
                              ),
                            ),
                          ],
                        ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                _searchQuery.trim().isEmpty
                    ? 'Recent notes'
                    : 'Search results (${_filteredNotes.length})',
                style: const TextStyle(
                  color: AppTheme.textSecondary,
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                  letterSpacing: 0.2,
                ),
              ),
            ),
            const SizedBox(height: 10),
            Expanded(
              child: _isLoading
                  ? const Center(
                      child: CircularProgressIndicator(
                        color: AppTheme.accent,
                        strokeWidth: 2,
                      ),
                    )
                  : _filteredNotes.isEmpty
                      ? _EmptyNotesState(
                          isSearching: _searchQuery.trim().isNotEmpty,
                        )
                      : ListView.separated(
                          padding: const EdgeInsets.fromLTRB(16, 0, 16, 96),
                          itemCount: _filteredNotes.length,
                          separatorBuilder: (_, _) => const SizedBox(height: 10),
                          itemBuilder: (context, index) {
                            final note = _filteredNotes[index];
                            return _NoteCard(
                              note: note,
                              timestampLabel: _formatTimestamp(note.updatedAt),
                              onTap: () => unawaited(_openEditor(note: note)),
                            );
                          },
                        ),
            ),
          ],
        ),
      ),
    );
  }
}

class _NoteCard extends StatelessWidget {
  const _NoteCard({
    required this.note,
    required this.timestampLabel,
    required this.onTap,
  });

  final Note note;
  final String timestampLabel;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppTheme.surface,
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: AppTheme.hairline),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                note.displayTitle,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: AppTheme.textPrimary,
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                note.preview,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: AppTheme.textSecondary,
                  fontSize: 13.5,
                  height: 1.4,
                ),
              ),
              const SizedBox(height: 10),
              Text(
                'Updated $timestampLabel',
                style: const TextStyle(
                  color: AppTheme.textMuted,
                  fontSize: 11.5,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _EmptyNotesState extends StatelessWidget {
  const _EmptyNotesState({required this.isSearching});

  final bool isSearching;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              isSearching ? Icons.search_off_outlined : Icons.note_alt_outlined,
              size: 40,
              color: AppTheme.textMuted,
            ),
            const SizedBox(height: 12),
            Text(
              isSearching ? 'No matching notes' : 'No notes yet',
              style: const TextStyle(
                color: AppTheme.textPrimary,
                fontSize: 16,
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              isSearching
                  ? 'Try a different keyword or clear the search bar.'
                  : 'Tap the + button to write your first note.',
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: AppTheme.textMuted,
                fontSize: 13.5,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
