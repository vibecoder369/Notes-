import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../core/theme/app_theme.dart';
import '../models/note.dart';
import '../services/local_notes_repository.dart';

class NoteEditorScreen extends StatefulWidget {
  const NoteEditorScreen({
    super.key,
    required this.note,
    required this.isNew,
    required this.notesRepository,
  });

  final Note note;
  final bool isNew;
  final LocalNotesRepository notesRepository;

  @override
  State<NoteEditorScreen> createState() => _NoteEditorScreenState();
}

class _NoteEditorScreenState extends State<NoteEditorScreen> {
  late final TextEditingController _titleController;
  late final TextEditingController _contentController;
  bool _hasChanged = false;
  bool _isSaving = false;

  @override
  void initState() {
    super.initState();
    _titleController = TextEditingController(text: widget.note.title);
    _contentController = TextEditingController(text: widget.note.content);
  }

  Future<void> _saveAndClose() async {
    if (_isSaving) return;
    final title = _titleController.text.trim();
    final content = _contentController.text.trim();

    if (widget.isNew && title.isEmpty && content.isEmpty) {
      Navigator.of(context).pop(false);
      return;
    }

    setState(() => _isSaving = true);
    final updated = widget.note.copyWith(
      title: _titleController.text,
      content: _contentController.text,
      updatedAt: DateTime.now(),
    );

    await widget.notesRepository.saveNote(updated);
    if (!mounted) return;
    Navigator.of(context).pop(true);
  }

  Future<void> _confirmDelete() async {
    if (widget.isNew) {
      Navigator.of(context).pop(false);
      return;
    }

    final shouldDelete = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text(
          'Delete note?',
          style: TextStyle(color: AppTheme.textPrimary, fontSize: 17),
        ),
        content: const Text(
          'This note will be permanently removed from this device.',
          style: TextStyle(color: AppTheme.textSecondary, fontSize: 14),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text(
              'Cancel',
              style: TextStyle(color: AppTheme.textSecondary),
            ),
          ),
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: const Text(
              'Delete',
              style: TextStyle(color: AppTheme.danger),
            ),
          ),
        ],
      ),
    );

    if (shouldDelete == true) {
      await widget.notesRepository.deleteNote(widget.note.id);
      if (!mounted) return;
      Navigator.of(context).pop(true);
    }
  }

  @override
  void dispose() {
    _titleController.dispose();
    _contentController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final updatedStr = DateFormat('MMM d, y · h:mm a').format(widget.note.updatedAt);

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop) return;
        if (_hasChanged) {
          await _saveAndClose();
        } else {
          Navigator.of(context).pop(false);
        }
      },
      child: Scaffold(
        appBar: AppBar(
          leading: IconButton(
            tooltip: 'Back',
            onPressed: () async {
              if (_hasChanged) {
                await _saveAndClose();
              } else {
                Navigator.of(context).pop(false);
              }
            },
            icon: const Icon(Icons.arrow_back),
          ),
          actions: [
            if (!widget.isNew)
              IconButton(
                tooltip: 'Delete note',
                onPressed: _confirmDelete,
                icon: const Icon(Icons.delete_outline, color: AppTheme.textSecondary),
              ),
            TextButton(
              onPressed: _saveAndClose,
              child: const Text(
                'Save',
                style: TextStyle(
                  color: AppTheme.accent,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            const SizedBox(width: 6),
          ],
        ),
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.isNew ? 'New note' : 'Last edited $updatedStr',
                  style: const TextStyle(
                    color: AppTheme.textMuted,
                    fontSize: 12,
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _titleController,
                  onChanged: (_) => _hasChanged = true,
                  style: const TextStyle(
                    color: AppTheme.textPrimary,
                    fontSize: 22,
                    fontWeight: FontWeight.w600,
                  ),
                  decoration: const InputDecoration(
                    hintText: 'Title',
                    hintStyle: TextStyle(color: AppTheme.textMuted),
                    filled: false,
                    border: InputBorder.none,
                    enabledBorder: InputBorder.none,
                    focusedBorder: InputBorder.none,
                    contentPadding: EdgeInsets.zero,
                  ),
                ),
                const SizedBox(height: 10),
                const Divider(color: AppTheme.hairline),
                const SizedBox(height: 10),
                Expanded(
                  child: TextField(
                    controller: _contentController,
                    onChanged: (_) => _hasChanged = true,
                    maxLines: null,
                    expands: true,
                    textAlignVertical: TextAlignVertical.top,
                    style: const TextStyle(
                      color: AppTheme.textPrimary,
                      fontSize: 15.5,
                      height: 1.55,
                    ),
                    decoration: const InputDecoration(
                      hintText: 'Start writing...',
                      hintStyle: TextStyle(color: AppTheme.textMuted),
                      filled: false,
                      border: InputBorder.none,
                      enabledBorder: InputBorder.none,
                      focusedBorder: InputBorder.none,
                      contentPadding: EdgeInsets.zero,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
