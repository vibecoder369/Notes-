import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:share_plus/share_plus.dart';

import '../core/theme/app_theme.dart';
import '../models/chat_models.dart';
import '../services/crypto_service.dart';
import '../services/private_chat_service.dart';
import '../services/secure_prefs_repository.dart';

class PrivateChatScreen extends StatefulWidget {
  const PrivateChatScreen({
    super.key,
    required this.securePrefs,
    required this.cryptoService,
  });

  final SecurePrefsRepository securePrefs;
  final CryptoService cryptoService;

  @override
  State<PrivateChatScreen> createState() => _PrivateChatScreenState();
}

class _PrivateChatScreenState extends State<PrivateChatScreen> {
  late final PrivateChatService _chatService;
  final TextEditingController _inviteCodeController = TextEditingController();
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  int _lastMessageCount = 0;

  @override
  void initState() {
    super.initState();
    _chatService = PrivateChatService(
      securePrefs: widget.securePrefs,
      cryptoService: widget.cryptoService,
    );
    _chatService.addListener(_onServiceUpdated);
    unawaited(_chatService.initializeAndRestore());
  }

  void _onServiceUpdated() {
    if (!mounted) return;
    final count = _chatService.messages.length;
    if (count > _lastMessageCount) {
      _lastMessageCount = count;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_scrollController.hasClients) {
          _scrollController.animateTo(
            _scrollController.position.maxScrollExtent,
            duration: const Duration(milliseconds: 180),
            curve: Curves.easeOut,
          );
        }
      });
    } else {
      _lastMessageCount = count;
    }
    setState(() {});
  }

  Future<void> _copyInviteCode(String code) async {
    await Clipboard.setData(ClipboardData(text: code));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Invitation code copied to clipboard.')),
    );
  }

  Future<void> _shareInviteCode(String code) async {
    await SharePlus.instance.share(
      ShareParams(
        text: 'Private Chat invitation code (single use): $code',
        subject: 'Private Chat Invitation',
      ),
    );
  }

  Future<void> _confirmLeaveRoom() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text(
          'Leave private room?',
          style: TextStyle(color: AppTheme.textPrimary, fontSize: 17),
        ),
        content: const Text(
          'Your local encryption keys for this room will be removed. If both participants leave, the room and its messages are deleted from the server.',
          style: TextStyle(
            color: AppTheme.textSecondary,
            fontSize: 13.5,
            height: 1.45,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text(
              'Cancel',
              style: TextStyle(color: AppTheme.textSecondary),
            ),
          ),
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: const Text(
              'Leave room',
              style: TextStyle(color: AppTheme.danger),
            ),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      await _chatService.leaveRoom();
    }
  }

  void _showRoomInfoSheet() {
    final session = _chatService.session;
    final fingerprint = _chatService.safetyFingerprint;

    showModalBottomSheet<void>(
      context: context,
      backgroundColor: AppTheme.surfaceElevated,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (sheetContext) {
        return Padding(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 36,
                  height: 4,
                  decoration: BoxDecoration(
                    color: AppTheme.hairline,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              const Text(
                'Room Security & Status',
                style: TextStyle(
                  color: AppTheme.textPrimary,
                  fontSize: 17,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 12),
              if (session?.inviteCode != null && !(session?.inviteUsed ?? true)) ...[
                const Text(
                  'Single-use invitation code',
                  style: TextStyle(color: AppTheme.textSecondary, fontSize: 12.5),
                ),
                const SizedBox(height: 6),
                Row(
                  children: [
                    Expanded(
                      child: SelectableText(
                        session!.inviteCode!,
                        style: const TextStyle(
                          color: AppTheme.textPrimary,
                          fontSize: 15,
                          fontWeight: FontWeight.w600,
                          letterSpacing: 1.0,
                        ),
                      ),
                    ),
                    IconButton(
                      tooltip: 'Copy',
                      onPressed: () => unawaited(_copyInviteCode(session.inviteCode!)),
                      icon: const Icon(Icons.copy, size: 18, color: AppTheme.textSecondary),
                    ),
                    IconButton(
                      tooltip: 'Share',
                      onPressed: () => unawaited(_shareInviteCode(session.inviteCode!)),
                      icon: const Icon(Icons.share_outlined, size: 18, color: AppTheme.textSecondary),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
              ],
              const Text(
                'Safety Fingerprint (X25519 + SHA-256)',
                style: TextStyle(color: AppTheme.textSecondary, fontSize: 12.5),
              ),
              const SizedBox(height: 6),
              Text(
                fingerprint ?? 'Available once both participants have joined.',
                style: const TextStyle(
                  color: AppTheme.textPrimary,
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                  letterSpacing: 0.8,
                ),
              ),
              const SizedBox(height: 12),
              const Text(
                'Compare this fingerprint with your partner on another channel to verify key integrity. '
                'Message payloads are encrypted client-side with AES-256-GCM; timestamps and room membership metadata remain visible to the server.',
                style: TextStyle(
                  color: AppTheme.textMuted,
                  fontSize: 12.5,
                  height: 1.45,
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  String _statusText(RoomConnectionStatus status) {
    switch (status) {
      case RoomConnectionStatus.disconnected:
        return 'No active room';
      case RoomConnectionStatus.connecting:
        return 'Connecting...';
      case RoomConnectionStatus.waitingForPeer:
        return 'Waiting for second participant';
      case RoomConnectionStatus.connected:
        return 'Connected · End-to-end encrypted';
      case RoomConnectionStatus.offlineError:
        return 'Connection issue';
    }
  }

  Color _statusColor(RoomConnectionStatus status) {
    switch (status) {
      case RoomConnectionStatus.connected:
        return AppTheme.success;
      case RoomConnectionStatus.waitingForPeer:
      case RoomConnectionStatus.connecting:
        return AppTheme.warning;
      case RoomConnectionStatus.offlineError:
        return AppTheme.danger;
      case RoomConnectionStatus.disconnected:
        return AppTheme.textMuted;
    }
  }

  Future<void> _sendCurrentMessage() async {
    final text = _messageController.text;
    if (text.trim().isEmpty) return;
    _messageController.clear();
    await _chatService.sendMessage(text);
  }

  @override
  void dispose() {
    _chatService.removeListener(_onServiceUpdated);
    _chatService.dispose();
    _inviteCodeController.dispose();
    _messageController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final session = _chatService.session;
    final status = _chatService.connectionStatus;

    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Private Chat',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
            ),
            Text(
              _statusText(status),
              style: TextStyle(
                color: _statusColor(status),
                fontSize: 12,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
        actions: [
          if (session != null) ...[
            IconButton(
              tooltip: 'Room info & safety fingerprint',
              onPressed: _showRoomInfoSheet,
              icon: const Icon(Icons.shield_outlined, color: AppTheme.textSecondary),
            ),
            IconButton(
              tooltip: 'Refresh connection',
              onPressed: _chatService.isBusy
                  ? null
                  : () => unawaited(_chatService.refreshSession()),
              icon: const Icon(Icons.refresh, color: AppTheme.textSecondary),
            ),
            PopupMenuButton<String>(
              color: AppTheme.surfaceElevated,
              icon: const Icon(Icons.more_vert, color: AppTheme.textSecondary),
              onSelected: (val) {
                if (val == 'leave') {
                  unawaited(_confirmLeaveRoom());
                }
              },
              itemBuilder: (_) => const [
                PopupMenuItem<String>(
                  value: 'leave',
                  child: Text(
                    'Leave room',
                    style: TextStyle(color: AppTheme.danger),
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            if (_chatService.errorMessage != null)
              Container(
                width: double.infinity,
                margin: const EdgeInsets.fromLTRB(16, 8, 16, 4),
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                decoration: BoxDecoration(
                  color: const Color(0xFF1F1215),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: const Color(0xFF4C1D24)),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Icon(Icons.error_outline, color: AppTheme.danger, size: 18),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        _chatService.errorMessage!,
                        style: const TextStyle(
                          color: AppTheme.textPrimary,
                          fontSize: 13,
                          height: 1.4,
                        ),
                      ),
                    ),
                    IconButton(
                      padding: EdgeInsets.zero,
                      constraints: const BoxConstraints(),
                      onPressed: _chatService.clearError,
                      icon: const Icon(Icons.close, color: AppTheme.textMuted, size: 18),
                    ),
                  ],
                ),
              ),
            Expanded(
              child: !_chatService.isConfigured
                  ? _BackendMissingView(onBack: () => Navigator.of(context).pop())
                  : session == null
                      ? _RoomSetupView(
                          inviteController: _inviteCodeController,
                          isBusy: _chatService.isBusy,
                          onCreateRoom: () => unawaited(_chatService.createRoom()),
                          onJoinRoom: () => unawaited(
                            _chatService.joinRoom(_inviteCodeController.text),
                          ),
                        )
                      : _ActiveChatView(
                          session: session,
                          messages: _chatService.messages,
                          canSend: _chatService.canSendEncrypted,
                          isBusy: _chatService.isBusy,
                          scrollController: _scrollController,
                          messageController: _messageController,
                          onCopyInvite: _copyInviteCode,
                          onShareInvite: _shareInviteCode,
                          onSend: _sendCurrentMessage,
                          onRetryFailed: (msg) =>
                              unawaited(_chatService.retryFailedMessage(msg)),
                        ),
            ),
          ],
        ),
      ),
    );
  }
}

class _BackendMissingView extends StatelessWidget {
  const _BackendMissingView({required this.onBack});

  final VoidCallback onBack;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.cloud_off_outlined, size: 42, color: AppTheme.textMuted),
            const SizedBox(height: 14),
            const Text(
              'Messaging Backend Unavailable',
              style: TextStyle(
                color: AppTheme.textPrimary,
                fontSize: 17,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Supabase credentials were not provided when building this APK. Local notes remain fully functional.',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: AppTheme.textSecondary,
                fontSize: 13.5,
                height: 1.45,
              ),
            ),
            const SizedBox(height: 18),
            OutlinedButton(
              onPressed: onBack,
              style: OutlinedButton.styleFrom(
                foregroundColor: AppTheme.textPrimary,
                side: const BorderSide(color: AppTheme.hairline),
              ),
              child: const Text('Return to Notes'),
            ),
          ],
        ),
      ),
    );
  }
}

class _RoomSetupView extends StatelessWidget {
  const _RoomSetupView({
    required this.inviteController,
    required this.isBusy,
    required this.onCreateRoom,
    required this.onJoinRoom,
  });

  final TextEditingController inviteController;
  final bool isBusy;
  final VoidCallback onCreateRoom;
  final VoidCallback onJoinRoom;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: AppTheme.surface,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppTheme.hairline),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Create a private room',
                style: TextStyle(
                  color: AppTheme.textPrimary,
                  fontSize: 17,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'Generate a single-use invitation code for one other person. No phone number or contacts needed.',
                style: TextStyle(
                  color: AppTheme.textSecondary,
                  fontSize: 13.5,
                  height: 1.45,
                ),
              ),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                height: 46,
                child: FilledButton(
                  style: FilledButton.styleFrom(
                    backgroundColor: AppTheme.accent,
                    foregroundColor: AppTheme.pureBlack,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  onPressed: isBusy ? null : onCreateRoom,
                  child: isBusy
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: AppTheme.pureBlack,
                          ),
                        )
                      : const Text(
                          'Create room & generate code',
                          style: TextStyle(fontWeight: FontWeight.w600),
                        ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: AppTheme.surface,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppTheme.hairline),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Join with invitation code',
                style: TextStyle(
                  color: AppTheme.textPrimary,
                  fontSize: 17,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'Enter the 16-character invitation code shared with you.',
                style: TextStyle(
                  color: AppTheme.textSecondary,
                  fontSize: 13.5,
                ),
              ),
              const SizedBox(height: 14),
              TextField(
                controller: inviteController,
                enabled: !isBusy,
                textCapitalization: TextCapitalization.characters,
                autocorrect: false,
                style: const TextStyle(
                  color: AppTheme.textPrimary,
                  letterSpacing: 1.1,
                ),
                decoration: const InputDecoration(
                  hintText: 'XXXX-XXXX-XXXX-XXXX',
                ),
              ),
              const SizedBox(height: 14),
              SizedBox(
                width: double.infinity,
                height: 46,
                child: OutlinedButton(
                  style: OutlinedButton.styleFrom(
                    foregroundColor: AppTheme.textPrimary,
                    side: const BorderSide(color: AppTheme.hairline),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  onPressed: isBusy ? null : onJoinRoom,
                  child: const Text(
                    'Join room',
                    style: TextStyle(fontWeight: FontWeight.w600),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _ActiveChatView extends StatelessWidget {
  const _ActiveChatView({
    required this.session,
    required this.messages,
    required this.canSend,
    required this.isBusy,
    required this.scrollController,
    required this.messageController,
    required this.onCopyInvite,
    required this.onShareInvite,
    required this.onSend,
    required this.onRetryFailed,
  });

  final RoomSession session;
  final List<ChatMessage> messages;
  final bool canSend;
  final bool isBusy;
  final ScrollController scrollController;
  final TextEditingController messageController;
  final Future<void> Function(String) onCopyInvite;
  final Future<void> Function(String) onShareInvite;
  final Future<void> Function() onSend;
  final void Function(ChatMessage) onRetryFailed;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        if (session.isCreator &&
            !session.hasPeer &&
            session.inviteCode != null)
          Container(
            width: double.infinity,
            margin: const EdgeInsets.fromLTRB(16, 10, 16, 6),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppTheme.surface,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: AppTheme.hairline),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Share single-use invitation code',
                  style: TextStyle(
                    color: AppTheme.textSecondary,
                    fontSize: 12.5,
                  ),
                ),
                const SizedBox(height: 8),
                SelectableText(
                  session.inviteCode!,
                  style: const TextStyle(
                    color: AppTheme.textPrimary,
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 1.4,
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () => unawaited(onCopyInvite(session.inviteCode!)),
                        icon: const Icon(Icons.copy, size: 16),
                        label: const Text('Copy'),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: AppTheme.textPrimary,
                          side: const BorderSide(color: AppTheme.hairline),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: FilledButton.icon(
                        onPressed: () => unawaited(onShareInvite(session.inviteCode!)),
                        icon: const Icon(Icons.share_outlined, size: 16),
                        label: const Text('Share'),
                        style: FilledButton.styleFrom(
                          backgroundColor: AppTheme.accent,
                          foregroundColor: AppTheme.pureBlack,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        Expanded(
          child: isBusy && messages.isEmpty
              ? const Center(
                  child: CircularProgressIndicator(
                    color: AppTheme.accent,
                    strokeWidth: 2,
                  ),
                )
              : messages.isEmpty
                  ? Center(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 32),
                        child: Text(
                          session.hasPeer
                              ? 'End-to-end encryption keys verified. Send your first message below.'
                              : 'Waiting for the second participant to join with the invitation code.',
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            color: AppTheme.textMuted,
                            fontSize: 13.5,
                            height: 1.45,
                          ),
                        ),
                      ),
                    )
                  : ListView.builder(
                      controller: scrollController,
                      padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
                      itemCount: messages.length,
                      itemBuilder: (context, index) {
                        final msg = messages[index];
                        return _MessageBubble(
                          message: msg,
                          onRetry: msg.status == MessageDeliveryStatus.failed
                              ? () => onRetryFailed(msg)
                              : null,
                        );
                      },
                    ),
        ),
        Container(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 14),
          decoration: const BoxDecoration(
            color: AppTheme.pureBlack,
            border: Border(top: BorderSide(color: AppTheme.hairline)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (!canSend)
                const Padding(
                  padding: EdgeInsets.only(bottom: 8),
                  child: Text(
                    'Messaging unlocks automatically once both participants are connected.',
                    style: TextStyle(color: AppTheme.textMuted, fontSize: 12),
                  ),
                ),
              Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Expanded(
                    child: TextField(
                      controller: messageController,
                      enabled: canSend,
                      minLines: 1,
                      maxLines: 4,
                      textCapitalization: TextCapitalization.sentences,
                      style: const TextStyle(
                        color: AppTheme.textPrimary,
                        fontSize: 15,
                      ),
                      decoration: InputDecoration(
                        hintText: canSend
                            ? 'Encrypted message...'
                            : 'Waiting for partner...',
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 12,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  SizedBox(
                    height: 48,
                    width: 48,
                    child: FilledButton(
                      style: FilledButton.styleFrom(
                        padding: EdgeInsets.zero,
                        backgroundColor: canSend ? AppTheme.accent : AppTheme.surface,
                        foregroundColor: canSend ? AppTheme.pureBlack : AppTheme.textMuted,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      onPressed: canSend ? () => unawaited(onSend()) : null,
                      child: const Icon(Icons.arrow_upward, size: 20),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _MessageBubble extends StatelessWidget {
  const _MessageBubble({
    required this.message,
    this.onRetry,
  });

  final ChatMessage message;
  final VoidCallback? onRetry;

  @override
  Widget build(BuildContext context) {
    final align = message.isMine ? CrossAxisAlignment.end : CrossAxisAlignment.start;
    final bubbleColor =
        message.isMine ? AppTheme.sentBubble : AppTheme.receivedBubble;
    final timeStr = DateFormat.jm().format(message.createdAt);

    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Column(
        crossAxisAlignment: align,
        children: [
          Container(
            constraints: BoxConstraints(
              maxWidth: MediaQuery.of(context).size.width * 0.78,
            ),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              color: bubbleColor,
              borderRadius: BorderRadius.only(
                topLeft: const Radius.circular(14),
                topRight: const Radius.circular(14),
                bottomLeft: Radius.circular(message.isMine ? 14 : 4),
                bottomRight: Radius.circular(message.isMine ? 4 : 14),
              ),
              border: Border.all(
                color: message.status == MessageDeliveryStatus.failed
                    ? AppTheme.danger
                    : AppTheme.hairline,
              ),
            ),
            child: Text(
              message.plaintext,
              style: TextStyle(
                color: message.decryptionError != null
                    ? AppTheme.textMuted
                    : AppTheme.textPrimary,
                fontSize: 15,
                height: 1.4,
              ),
            ),
          ),
          const SizedBox(height: 4),
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                timeStr,
                style: const TextStyle(color: AppTheme.textMuted, fontSize: 11),
              ),
              if (message.isMine &&
                  message.status == MessageDeliveryStatus.sending) ...[
                const SizedBox(width: 6),
                const Text(
                  'Sending...',
                  style: TextStyle(color: AppTheme.textMuted, fontSize: 11),
                ),
              ],
              if (message.isMine &&
                  message.status == MessageDeliveryStatus.failed) ...[
                const SizedBox(width: 8),
                GestureDetector(
                  onTap: onRetry,
                  child: const Text(
                    'Failed · Tap to retry',
                    style: TextStyle(
                      color: AppTheme.danger,
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ],
          ),
        ],
      ),
    );
  }
}
