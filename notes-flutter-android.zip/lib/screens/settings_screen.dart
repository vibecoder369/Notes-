import 'dart:async';

import 'package:flutter/material.dart';

import '../core/theme/app_theme.dart';
import '../services/secure_prefs_repository.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({
    super.key,
    required this.securePrefs,
  });

  final SecurePrefsRepository securePrefs;

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _hasKeyword = false;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    unawaited(_loadStatus());
  }

  Future<void> _loadStatus() async {
    final configured = await widget.securePrefs.hasSecretKeyword();
    if (!mounted) return;
    setState(() {
      _hasKeyword = configured;
      _isLoading = false;
    });
  }

  Future<void> _editSecretKeyword() async {
    final currentKeyword = await widget.securePrefs.getSecretKeyword();
    if (!mounted) return;

    final currentController = TextEditingController();
    final newController = TextEditingController();
    final confirmController = TextEditingController();
    String? errorText;
    bool obscure = true;

    await showDialog<void>(
      context: context,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              title: Text(
                currentKeyword == null || currentKeyword.isEmpty
                    ? 'Set secret keyword'
                    : 'Change secret keyword',
                style: const TextStyle(
                  color: AppTheme.textPrimary,
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                ),
              ),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'The keyword is never displayed openly. Entering the exact keyword in the Notes search bar opens Private Chat.',
                      style: TextStyle(
                        color: AppTheme.textSecondary,
                        fontSize: 13,
                        height: 1.4,
                      ),
                    ),
                    const SizedBox(height: 14),
                    if (currentKeyword != null && currentKeyword.isNotEmpty) ...[
                      TextField(
                        controller: currentController,
                        obscureText: obscure,
                        autocorrect: false,
                        enableSuggestions: false,
                        style: const TextStyle(color: AppTheme.textPrimary),
                        decoration: const InputDecoration(
                          hintText: 'Current keyword',
                        ),
                      ),
                      const SizedBox(height: 10),
                    ],
                    TextField(
                      controller: newController,
                      obscureText: obscure,
                      autocorrect: false,
                      enableSuggestions: false,
                      style: const TextStyle(color: AppTheme.textPrimary),
                      decoration: InputDecoration(
                        hintText: 'New secret keyword',
                        suffixIcon: IconButton(
                          onPressed: () =>
                              setDialogState(() => obscure = !obscure),
                          icon: Icon(
                            obscure
                                ? Icons.visibility_outlined
                                : Icons.visibility_off_outlined,
                            color: AppTheme.textSecondary,
                            size: 20,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    TextField(
                      controller: confirmController,
                      obscureText: obscure,
                      autocorrect: false,
                      enableSuggestions: false,
                      style: const TextStyle(color: AppTheme.textPrimary),
                      decoration: const InputDecoration(
                        hintText: 'Confirm new keyword',
                      ),
                    ),
                    if (errorText != null) ...[
                      const SizedBox(height: 10),
                      Text(
                        errorText!,
                        style: const TextStyle(
                          color: AppTheme.danger,
                          fontSize: 12.5,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
              actions: [
                if (currentKeyword != null && currentKeyword.isNotEmpty)
                  TextButton(
                    onPressed: () async {
                      if (currentController.text.trim() != currentKeyword) {
                        setDialogState(() {
                          errorText = 'Current keyword does not match.';
                        });
                        return;
                      }
                      await widget.securePrefs.setSecretKeyword('');
                      if (dialogContext.mounted) {
                        Navigator.of(dialogContext).pop();
                      }
                    },
                    child: const Text(
                      'Disable',
                      style: TextStyle(color: AppTheme.danger),
                    ),
                  ),
                TextButton(
                  onPressed: () => Navigator.of(dialogContext).pop(),
                  child: const Text(
                    'Cancel',
                    style: TextStyle(color: AppTheme.textSecondary),
                  ),
                ),
                FilledButton(
                  style: FilledButton.styleFrom(
                    backgroundColor: AppTheme.accent,
                    foregroundColor: AppTheme.pureBlack,
                  ),
                  onPressed: () async {
                    if (currentKeyword != null &&
                        currentKeyword.isNotEmpty &&
                        currentController.text.trim() != currentKeyword) {
                      setDialogState(() {
                        errorText = 'Current keyword does not match.';
                      });
                      return;
                    }

                    final next = newController.text.trim();
                    final confirm = confirmController.text.trim();

                    if (next.length < 3) {
                      setDialogState(() {
                        errorText = 'Keyword must be at least 3 characters.';
                      });
                      return;
                    }
                    if (next != confirm) {
                      setDialogState(() {
                        errorText = 'Keywords do not match.';
                      });
                      return;
                    }

                    await widget.securePrefs.setSecretKeyword(next);
                    if (dialogContext.mounted) {
                      Navigator.of(dialogContext).pop();
                    }
                  },
                  child: const Text('Save'),
                ),
              ],
            );
          },
        );
      },
    );

    currentController.dispose();
    newController.dispose();
    confirmController.dispose();

    await _loadStatus();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Keyword settings updated.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
      ),
      body: SafeArea(
        child: _isLoading
            ? const Center(
                child: CircularProgressIndicator(
                  color: AppTheme.accent,
                  strokeWidth: 2,
                ),
              )
            : ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  const Text(
                    'Access & Storage',
                    style: TextStyle(
                      color: AppTheme.textSecondary,
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Container(
                    decoration: BoxDecoration(
                      color: AppTheme.surface,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: AppTheme.hairline),
                    ),
                    child: ListTile(
                      onTap: _editSecretKeyword,
                      title: const Text(
                        'Search trigger keyword',
                        style: TextStyle(
                          color: AppTheme.textPrimary,
                          fontSize: 15.5,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      subtitle: Text(
                        _hasKeyword
                            ? 'Configured (hidden)'
                            : 'Not configured',
                        style: const TextStyle(
                          color: AppTheme.textSecondary,
                          fontSize: 13,
                        ),
                      ),
                      trailing: const Icon(
                        Icons.chevron_right,
                        color: AppTheme.textMuted,
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),
                  const Text(
                    'Privacy & Encryption Architecture',
                    style: TextStyle(
                      color: AppTheme.textSecondary,
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: AppTheme.surface,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: AppTheme.hairline),
                    ),
                    child: const Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Local Notes',
                          style: TextStyle(
                            color: AppTheme.textPrimary,
                            fontSize: 14.5,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        SizedBox(height: 4),
                        Text(
                          'Standard notes are stored locally on your device and never transmitted to any server.',
                          style: TextStyle(
                            color: AppTheme.textSecondary,
                            fontSize: 13,
                            height: 1.45,
                          ),
                        ),
                        SizedBox(height: 14),
                        Text(
                          'Private Chat & Limitations',
                          style: TextStyle(
                            color: AppTheme.textPrimary,
                            fontSize: 14.5,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        SizedBox(height: 4),
                        Text(
                          'Message contents are encrypted on-device using X25519 key agreement, HKDF-SHA256, and AES-256-GCM before upload. '
                          'However, metadata (room ID, anonymous user ID, timestamps, membership, and payload length) remains visible to the Supabase backend. '
                          'Always verify your partner\'s Safety Fingerprint out-of-band to detect server-side public key substitution.',
                          style: TextStyle(
                            color: AppTheme.textSecondary,
                            fontSize: 13,
                            height: 1.45,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
      ),
    );
  }
}
