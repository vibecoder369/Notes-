import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';

import '../models/note.dart';

class LocalNotesRepository {
  LocalNotesRepository({SharedPreferences? prefs}) : _injectedPrefs = prefs;

  static const String _notesKey = 'notes_local_items_v1';
  static const String _seededKey = 'notes_seeded_v1';
  static const Uuid _uuid = Uuid();

  final SharedPreferences? _injectedPrefs;
  SharedPreferences? _cachedPrefs;

  Future<SharedPreferences> _prefs() async {
    if (_injectedPrefs != null) return _injectedPrefs;
    return _cachedPrefs ??= await SharedPreferences.getInstance();
  }

  Future<List<Note>> loadNotes() async {
    final prefs = await _prefs();
    final hasSeeded = prefs.getBool(_seededKey) ?? false;

    if (!hasSeeded) {
      final initialNotes = _defaultExampleNotes();
      await _persistNotes(prefs, initialNotes);
      await prefs.setBool(_seededKey, true);
      return initialNotes;
    }

    final raw = prefs.getString(_notesKey);
    if (raw == null || raw.isEmpty) {
      return [];
    }

    try {
      final decoded = jsonDecode(raw) as List<dynamic>;
      final notes = decoded
          .whereType<Map<String, dynamic>>()
          .map(Note.fromJson)
          .toList();
      notes.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
      return notes;
    } catch (_) {
      return [];
    }
  }

  Future<List<Note>> saveNote(Note note) async {
    final prefs = await _prefs();
    final existing = await loadNotes();
    final index = existing.indexWhere((item) => item.id == note.id);

    if (index >= 0) {
      existing[index] = note;
    } else {
      existing.insert(0, note);
    }

    existing.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    await _persistNotes(prefs, existing);
    return existing;
  }

  Future<List<Note>> deleteNote(String id) async {
    final prefs = await _prefs();
    final existing = await loadNotes();
    existing.removeWhere((item) => item.id == id);
    await _persistNotes(prefs, existing);
    return existing;
  }

  Note createEmptyNote() {
    final now = DateTime.now();
    return Note(
      id: _uuid.v4(),
      title: '',
      content: '',
      createdAt: now,
      updatedAt: now,
    );
  }

  List<Note> searchNotes(List<Note> allNotes, String query) {
    final q = query.trim().toLowerCase();
    if (q.isEmpty) return allNotes;

    return allNotes.where((note) {
      return note.title.toLowerCase().contains(q) ||
          note.content.toLowerCase().contains(q);
    }).toList();
  }

  Future<void> _persistNotes(SharedPreferences prefs, List<Note> notes) async {
    final encoded = jsonEncode(notes.map((n) => n.toJson()).toList());
    await prefs.setString(_notesKey, encoded);
  }

  List<Note> _defaultExampleNotes() {
    final now = DateTime.now();
    return [
      Note(
        id: _uuid.v4(),
        title: 'Things to remember',
        content:
            '- Pick up replacement USB-C cable\n- Renew library books before Friday\n- Check electricity meter reading',
        createdAt: now.subtract(const Duration(days: 3)),
        updatedAt: now.subtract(const Duration(hours: 2)),
      ),
      Note(
        id: _uuid.v4(),
        title: 'College',
        content:
            'Algorithms assignment due Thursday 5 PM.\nReview graph traversal complexity and dynamic programming notes.',
        createdAt: now.subtract(const Duration(days: 5)),
        updatedAt: now.subtract(const Duration(days: 1)),
      ),
      Note(
        id: _uuid.v4(),
        title: 'Quick notes',
        content:
            'Grocery list: oats, coffee beans, olive oil, almonds, sparkling water.',
        createdAt: now.subtract(const Duration(days: 7)),
        updatedAt: now.subtract(const Duration(days: 2)),
      ),
    ];
  }
}
