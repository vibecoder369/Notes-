import 'dart:convert';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import '../models/chat_models.dart';

class SecurePrefsRepository {
  SecurePrefsRepository({FlutterSecureStorage? storage})
      : _storage = storage ??
            const FlutterSecureStorage(
              aOptions: AndroidOptions(
                encryptedSharedPreferences: true,
              ),
            );

  static const String _secretKeywordKey = 'notes_secret_keyword_v1';
  static const String _setupCompletedKey = 'notes_initial_setup_done_v1';
  static const String _activeRoomSessionKey = 'notes_active_room_session_v1';

  final FlutterSecureStorage _storage;

  static bool isExactSecretKeyword(String query, String? storedKeyword) {
    if (storedKeyword == null) return false;
    final configured = storedKeyword.trim();
    if (configured.isEmpty) return false;
    return query.trim() == configured;
  }

  Future<bool> isInitialSetupCompleted() async {
    final val = await _storage.read(key: _setupCompletedKey);
    return val == 'true';
  }

  Future<void> markInitialSetupCompleted() async {
    await _storage.write(key: _setupCompletedKey, value: 'true');
  }

  Future<String?> getSecretKeyword() async {
    return _storage.read(key: _secretKeywordKey);
  }

  Future<bool> hasSecretKeyword() async {
    final kw = await getSecretKeyword();
    return kw != null && kw.trim().isNotEmpty;
  }

  Future<void> setSecretKeyword(String keyword) async {
    final trimmed = keyword.trim();
    if (trimmed.isEmpty) {
      await _storage.delete(key: _secretKeywordKey);
    } else {
      await _storage.write(key: _secretKeywordKey, value: trimmed);
    }
    await markInitialSetupCompleted();
  }

  Future<bool> matchesSecretKeyword(String query) async {
    final stored = await getSecretKeyword();
    return isExactSecretKeyword(query, stored);
  }

  Future<RoomSession?> getActiveRoomSession() async {
    final raw = await _storage.read(key: _activeRoomSessionKey);
    if (raw == null || raw.isEmpty) return null;
    try {
      return RoomSession.fromJson(jsonDecode(raw) as Map<String, dynamic>);
    } catch (_) {
      return null;
    }
  }

  Future<void> saveActiveRoomSession(RoomSession session) async {
    await _storage.write(
      key: _activeRoomSessionKey,
      value: jsonEncode(session.toJson()),
    );
  }

  Future<void> clearActiveRoomSession() async {
    await _storage.delete(key: _activeRoomSessionKey);
  }

  Future<void> saveRoomKeyPair({
    required String roomId,
    required String privateKeyBase64,
    required String publicKeyBase64,
  }) async {
    await _storage.write(
      key: 'room_sk_$roomId',
      value: privateKeyBase64,
    );
    await _storage.write(
      key: 'room_pk_$roomId',
      value: publicKeyBase64,
    );
  }

  Future<({String privateKeyBase64, String publicKeyBase64})?> getRoomKeyPair(
    String roomId,
  ) async {
    final sk = await _storage.read(key: 'room_sk_$roomId');
    final pk = await _storage.read(key: 'room_pk_$roomId');
    if (sk == null || pk == null || sk.isEmpty || pk.isEmpty) {
      return null;
    }
    return (privateKeyBase64: sk, publicKeyBase64: pk);
  }

  Future<void> clearRoomCryptoAndDrafts(String roomId) async {
    await _storage.delete(key: 'room_sk_$roomId');
    await _storage.delete(key: 'room_pk_$roomId');
    await _storage.delete(key: 'room_unsent_$roomId');
  }

  Future<List<UnsentMessageDraft>> getUnsentDrafts(String roomId) async {
    final raw = await _storage.read(key: 'room_unsent_$roomId');
    if (raw == null || raw.isEmpty) return [];
    try {
      final list = jsonDecode(raw) as List<dynamic>;
      return list
          .whereType<Map<String, dynamic>>()
          .map(UnsentMessageDraft.fromJson)
          .toList();
    } catch (_) {
      return [];
    }
  }

  Future<void> saveUnsentDrafts(
    String roomId,
    List<UnsentMessageDraft> drafts,
  ) async {
    if (drafts.isEmpty) {
      await _storage.delete(key: 'room_unsent_$roomId');
      return;
    }
    await _storage.write(
      key: 'room_unsent_$roomId',
      value: jsonEncode(drafts.map((d) => d.toJson()).toList()),
    );
  }
}
