import 'dart:async';
import 'dart:io';

import 'package:cryptography/cryptography.dart';
import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';

import '../core/config/supabase_config.dart';
import '../models/chat_models.dart';
import 'crypto_service.dart';
import 'secure_prefs_repository.dart';

class PrivateChatException implements Exception {
  PrivateChatException(this.message);
  final String message;

  @override
  String toString() => message;
}

class PrivateChatService extends ChangeNotifier {
  PrivateChatService({
    required SecurePrefsRepository securePrefs,
    required CryptoService cryptoService,
  })  : _securePrefs = securePrefs,
        _crypto = cryptoService;

  static const Uuid _uuid = Uuid();

  final SecurePrefsRepository _securePrefs;
  final CryptoService _crypto;

  RoomSession? _session;
  RoomConnectionStatus _connectionStatus = RoomConnectionStatus.disconnected;
  List<ChatMessage> _messages = [];
  SecretKey? _sharedKey;
  String? _safetyFingerprint;
  String? _errorMessage;
  bool _isBusy = false;
  RealtimeChannel? _roomChannel;
  bool _disposed = false;

  RoomSession? get session => _session;
  RoomConnectionStatus get connectionStatus => _connectionStatus;
  List<ChatMessage> get messages => List.unmodifiable(_messages);
  String? get safetyFingerprint => _safetyFingerprint;
  String? get errorMessage => _errorMessage;
  bool get isBusy => _isBusy;
  bool get isConfigured => SupabaseConfig.isConfigured && SupabaseConfig.isInitialized;
  bool get canSendEncrypted =>
      _session != null &&
      _session!.hasPeer &&
      _sharedKey != null &&
      _connectionStatus == RoomConnectionStatus.connected;

  String? get currentUserId => SupabaseConfig.client?.auth.currentUser?.id;

  void _safeNotify() {
    if (!_disposed) {
      notifyListeners();
    }
  }

  void clearError() {
    _errorMessage = null;
    _safeNotify();
  }

  Future<void> initializeAndRestore() async {
    if (!SupabaseConfig.isConfigured || !SupabaseConfig.isInitialized) {
      _connectionStatus = RoomConnectionStatus.offlineError;
      _errorMessage = SupabaseConfig.initError ??
          'Private messaging backend is not configured in this build.';
      _safeNotify();
      return;
    }

    _isBusy = true;
    _errorMessage = null;
    _safeNotify();

    try {
      await _ensureAnonymousAuth();
      final savedSession = await _securePrefs.getActiveRoomSession();
      if (savedSession != null) {
        await _restoreServerSession(savedSession);
      } else {
        _connectionStatus = RoomConnectionStatus.disconnected;
      }
    } catch (e) {
      _connectionStatus = RoomConnectionStatus.offlineError;
      _errorMessage = _mapFriendlyError(e);
    } finally {
      _isBusy = false;
      _safeNotify();
    }
  }

  Future<void> createRoom() async {
    final client = SupabaseConfig.client;
    if (client == null) {
      _errorMessage = SupabaseConfig.initError ?? 'Backend unavailable.';
      _safeNotify();
      return;
    }

    _isBusy = true;
    _errorMessage = null;
    _connectionStatus = RoomConnectionStatus.connecting;
    _safeNotify();

    try {
      await _ensureAnonymousAuth();
      final keyPair = await _crypto.generateKeyPair();

      final dynamic response = await client
          .rpc(
            'create_private_room',
            params: {'p_public_key': keyPair.publicKeyBase64},
          )
          .timeout(const Duration(seconds: 15));

      final data = Map<String, dynamic>.from(response as Map);
      final roomId = data['room_id'] as String;
      final inviteCode = data['invite_code'] as String;
      final createdAt = DateTime.parse(data['created_at'] as String).toLocal();

      await _securePrefs.saveRoomKeyPair(
        roomId: roomId,
        privateKeyBase64: keyPair.privateKeyBase64,
        publicKeyBase64: keyPair.publicKeyBase64,
      );

      final newSession = RoomSession(
        roomId: roomId,
        isCreator: true,
        joinedAt: createdAt,
        inviteUsed: false,
        inviteCode: inviteCode,
      );

      await _securePrefs.saveActiveRoomSession(newSession);
      _session = newSession;
      _messages = [];
      _sharedKey = null;
      _safetyFingerprint = null;
      _connectionStatus = RoomConnectionStatus.waitingForPeer;

      await _subscribeToRoom(roomId);
      await _loadUnsentDrafts(roomId);
    } catch (e) {
      _connectionStatus = RoomConnectionStatus.offlineError;
      _errorMessage = _mapFriendlyError(e);
    } finally {
      _isBusy = false;
      _safeNotify();
    }
  }

  Future<void> joinRoom(String inviteCode) async {
    final client = SupabaseConfig.client;
    if (client == null) {
      _errorMessage = SupabaseConfig.initError ?? 'Backend unavailable.';
      _safeNotify();
      return;
    }

    final trimmed = inviteCode.trim();
    if (trimmed.isEmpty) {
      _errorMessage = 'Please enter an invitation code.';
      _safeNotify();
      return;
    }

    _isBusy = true;
    _errorMessage = null;
    _connectionStatus = RoomConnectionStatus.connecting;
    _safeNotify();

    try {
      await _ensureAnonymousAuth();
      final keyPair = await _crypto.generateKeyPair();

      final dynamic response = await client
          .rpc(
            'join_private_room',
            params: {
              'p_invite_code': trimmed,
              'p_public_key': keyPair.publicKeyBase64,
            },
          )
          .timeout(const Duration(seconds: 15));

      final data = Map<String, dynamic>.from(response as Map);
      final roomId = data['room_id'] as String;
      final joinedAt = DateTime.parse(data['joined_at'] as String).toLocal();
      final inviteUsed = (data['invite_used'] as bool?) ?? true;
      final peerPublicKey = data['peer_public_key'] as String?;

      // Preserve existing keypair if re-entering own room, else store new keypair.
      final existingKeyPair = await _securePrefs.getRoomKeyPair(roomId);
      final effectiveKeyPair = existingKeyPair ??
          (
            privateKeyBase64: keyPair.privateKeyBase64,
            publicKeyBase64: keyPair.publicKeyBase64,
          );

      if (existingKeyPair == null) {
        await _securePrefs.saveRoomKeyPair(
          roomId: roomId,
          privateKeyBase64: keyPair.privateKeyBase64,
          publicKeyBase64: keyPair.publicKeyBase64,
        );
      }

      final newSession = RoomSession(
        roomId: roomId,
        isCreator: false,
        joinedAt: joinedAt,
        inviteUsed: inviteUsed,
        peerPublicKey: peerPublicKey,
      );

      await _securePrefs.saveActiveRoomSession(newSession);
      _session = newSession;
      await _deriveKeysIfPeerPresent(effectiveKeyPair.publicKeyBase64);
      await _fetchMessageHistory(roomId);
      await _loadUnsentDrafts(roomId);
      await _subscribeToRoom(roomId);
    } catch (e) {
      _connectionStatus = RoomConnectionStatus.disconnected;
      _errorMessage = _mapFriendlyError(e);
    } finally {
      _isBusy = false;
      _safeNotify();
    }
  }

  Future<void> refreshSession() async {
    final active = _session ?? await _securePrefs.getActiveRoomSession();
    if (active == null) return;
    _isBusy = true;
    _errorMessage = null;
    _safeNotify();
    try {
      await _ensureAnonymousAuth();
      await _restoreServerSession(active);
    } catch (e) {
      _connectionStatus = RoomConnectionStatus.offlineError;
      _errorMessage = _mapFriendlyError(e);
    } finally {
      _isBusy = false;
      _safeNotify();
    }
  }

  Future<void> sendMessage(String rawText) async {
    final trimmed = rawText.trim();
    if (trimmed.isEmpty) return;

    final session = _session;
    final sharedKey = _sharedKey;
    final client = SupabaseConfig.client;
    final userId = currentUserId;

    if (session == null || sharedKey == null) {
      _errorMessage =
          'Wait until the second participant joins so end-to-end keys can be established.';
      _safeNotify();
      return;
    }

    final localId = 'local_${_uuid.v4()}';
    final now = DateTime.now();
    final optimistic = ChatMessage(
      id: localId,
      roomId: session.roomId,
      authorId: userId ?? 'local',
      plaintext: trimmed,
      createdAt: now,
      isMine: true,
      status: MessageDeliveryStatus.sending,
    );

    _messages = [..._messages, optimistic];
    _errorMessage = null;
    _safeNotify();

    if (client == null || userId == null) {
      await _markMessageFailed(session.roomId, localId, trimmed, now,
          'Not connected to backend. Message saved locally for retry.');
      return;
    }

    try {
      final envelope = await _crypto.encryptMessage(
        plaintext: trimmed,
        sharedKey: sharedKey,
        roomId: session.roomId,
        authorId: userId,
      );

      final dynamic inserted = await client
          .from('messages')
          .insert({
            'room_id': session.roomId,
            'author_id': userId,
            'body': envelope,
          })
          .select()
          .single()
          .timeout(const Duration(seconds: 12));

      final row = Map<String, dynamic>.from(inserted as Map);
      final serverId = row['id'] as String;
      final serverCreatedAt =
          DateTime.parse(row['created_at'] as String).toLocal();

      _messages = _messages.map((msg) {
        if (msg.id == localId) {
          return msg.copyWith(
            id: serverId,
            createdAt: serverCreatedAt,
            status: MessageDeliveryStatus.sent,
          );
        }
        return msg;
      }).toList();

      // Deduplicate in case Realtime delivered the row concurrently.
      _deduplicateMessages();
      await _removeUnsentDraft(session.roomId, localId);
      _safeNotify();
    } catch (e) {
      await _markMessageFailed(
        session.roomId,
        localId,
        trimmed,
        now,
        _mapFriendlyError(e),
      );
    }
  }

  Future<void> retryFailedMessage(ChatMessage failedMessage) async {
    final session = _session;
    final sharedKey = _sharedKey;
    final client = SupabaseConfig.client;
    final userId = currentUserId;

    if (session == null || sharedKey == null || client == null || userId == null) {
      _errorMessage = 'Still offline or session keys unavailable.';
      _safeNotify();
      return;
    }

    _messages = _messages.map((m) {
      if (m.id == failedMessage.id) {
        return m.copyWith(status: MessageDeliveryStatus.sending);
      }
      return m;
    }).toList();
    _errorMessage = null;
    _safeNotify();

    try {
      final envelope = await _crypto.encryptMessage(
        plaintext: failedMessage.plaintext,
        sharedKey: sharedKey,
        roomId: session.roomId,
        authorId: userId,
      );

      final dynamic inserted = await client
          .from('messages')
          .insert({
            'room_id': session.roomId,
            'author_id': userId,
            'body': envelope,
          })
          .select()
          .single()
          .timeout(const Duration(seconds: 12));

      final row = Map<String, dynamic>.from(inserted as Map);
      final serverId = row['id'] as String;
      final serverCreatedAt =
          DateTime.parse(row['created_at'] as String).toLocal();

      _messages = _messages.map((m) {
        if (m.id == failedMessage.id) {
          return m.copyWith(
            id: serverId,
            createdAt: serverCreatedAt,
            status: MessageDeliveryStatus.sent,
          );
        }
        return m;
      }).toList();

      _deduplicateMessages();
      await _removeUnsentDraft(session.roomId, failedMessage.id);
      _safeNotify();
    } catch (e) {
      _messages = _messages.map((m) {
        if (m.id == failedMessage.id) {
          return m.copyWith(status: MessageDeliveryStatus.failed);
        }
        return m;
      }).toList();
      _errorMessage = _mapFriendlyError(e);
      _safeNotify();
    }
  }

  Future<void> leaveRoom() async {
    final session = _session;
    final client = SupabaseConfig.client;

    _isBusy = true;
    _errorMessage = null;
    _safeNotify();

    try {
      await _unsubscribeChannel();
      if (session != null && client != null && client.auth.currentUser != null) {
        await client
            .rpc('leave_private_room', params: {'p_room_id': session.roomId})
            .timeout(const Duration(seconds: 10));
      }
    } catch (e) {
      // Even if network fails when leaving, clear local session & keys cleanly
      // so the user is never trapped in a room locally, and report warning.
      _errorMessage = 'Left locally. Server cleanup failed: ${_mapFriendlyError(e)}';
    } finally {
      if (session != null) {
        await _securePrefs.clearRoomCryptoAndDrafts(session.roomId);
      }
      await _securePrefs.clearActiveRoomSession();
      _session = null;
      _messages = [];
      _sharedKey = null;
      _safetyFingerprint = null;
      _connectionStatus = RoomConnectionStatus.disconnected;
      _isBusy = false;
      _safeNotify();
    }
  }

  Future<void> _ensureAnonymousAuth() async {
    final client = SupabaseConfig.client;
    if (client == null) {
      throw PrivateChatException('Backend client is not initialized.');
    }

    if (client.auth.currentSession == null || client.auth.currentUser == null) {
      await client.auth.signInAnonymously().timeout(const Duration(seconds: 12));
    }
  }

  Future<void> _restoreServerSession(RoomSession savedSession) async {
    final client = SupabaseConfig.client;
    if (client == null) return;

    try {
      final dynamic response = await client
          .rpc(
            'restore_room_session',
            params: {'p_room_id': savedSession.roomId},
          )
          .timeout(const Duration(seconds: 12));

      final data = Map<String, dynamic>.from(response as Map);
      final peerPublicKey = data['peer_public_key'] as String?;
      final inviteUsed = (data['invite_used'] as bool?) ?? savedSession.inviteUsed;
      final inviteCode = data['invite_code'] as String?;
      final isCreator = (data['is_creator'] as bool?) ?? savedSession.isCreator;

      final keyPair = await _securePrefs.getRoomKeyPair(savedSession.roomId);
      if (keyPair == null) {
        await _securePrefs.clearActiveRoomSession();
        _session = null;
        _connectionStatus = RoomConnectionStatus.disconnected;
        _errorMessage =
            'Local encryption keys for the previous room were missing. Please create or join a new room.';
        return;
      }

      final updated = savedSession.copyWith(
        isCreator: isCreator,
        inviteUsed: inviteUsed,
        inviteCode: inviteCode,
        clearInviteCode: inviteCode == null,
        peerPublicKey: peerPublicKey,
        clearPeerPublicKey: peerPublicKey == null,
      );

      await _securePrefs.saveActiveRoomSession(updated);
      _session = updated;

      await _deriveKeysIfPeerPresent(keyPair.publicKeyBase64);
      await _fetchMessageHistory(updated.roomId);
      await _loadUnsentDrafts(updated.roomId);
      await _subscribeToRoom(updated.roomId);
    } on PostgrestException catch (e) {
      if (e.message.contains('ROOM_NOT_FOUND') || e.message.contains('NOT_A_MEMBER')) {
        await _securePrefs.clearRoomCryptoAndDrafts(savedSession.roomId);
        await _securePrefs.clearActiveRoomSession();
        _session = null;
        _messages = [];
        _sharedKey = null;
        _safetyFingerprint = null;
        _connectionStatus = RoomConnectionStatus.disconnected;
        _errorMessage = 'Your previous private room is no longer active.';
      } else {
        rethrow;
      }
    }
  }

  Future<void> _deriveKeysIfPeerPresent(String myPublicKeyBase64) async {
    final session = _session;
    if (session == null || !session.hasPeer) {
      _sharedKey = null;
      _safetyFingerprint = null;
      _connectionStatus = RoomConnectionStatus.waitingForPeer;
      return;
    }

    final keyPair = await _securePrefs.getRoomKeyPair(session.roomId);
    if (keyPair == null) {
      throw PrivateChatException('Local encryption keypair not found.');
    }

    _sharedKey = await _crypto.deriveSharedKey(
      myPrivateKeyBase64: keyPair.privateKeyBase64,
      peerPublicKeyBase64: session.peerPublicKey!,
      roomId: session.roomId,
    );

    _safetyFingerprint = await _crypto.computeSafetyFingerprint(
      publicKeyA: myPublicKeyBase64,
      publicKeyB: session.peerPublicKey!,
    );

    _connectionStatus = RoomConnectionStatus.connected;
  }

  Future<void> _fetchMessageHistory(String roomId) async {
    final client = SupabaseConfig.client;
    if (client == null) return;

    final dynamic rows = await client
        .from('messages')
        .select('id, room_id, author_id, body, created_at')
        .eq('room_id', roomId)
        .order('created_at', ascending: true)
        .timeout(const Duration(seconds: 12));

    final myId = currentUserId;
    final loaded = <ChatMessage>[];

    for (final raw in (rows as List<dynamic>)) {
      final map = Map<String, dynamic>.from(raw as Map);
      loaded.add(await _decryptRow(map, myId));
    }

    _messages = loaded;
  }

  Future<ChatMessage> _decryptRow(
    Map<String, dynamic> row,
    String? myId,
  ) async {
    final id = row['id'] as String;
    final roomId = row['room_id'] as String;
    final authorId = row['author_id'] as String;
    final body = row['body'] as String;
    final createdAt = DateTime.parse(row['created_at'] as String).toLocal();
    final isMine = myId != null && authorId == myId;

    if (_sharedKey == null) {
      return ChatMessage(
        id: id,
        roomId: roomId,
        authorId: authorId,
        plaintext: '[Encrypted message — waiting for key exchange]',
        createdAt: createdAt,
        isMine: isMine,
        status: MessageDeliveryStatus.sent,
        decryptionError: 'Shared key not yet established',
      );
    }

    try {
      final clear = await _crypto.decryptMessage(
        envelope: body,
        sharedKey: _sharedKey!,
        roomId: roomId,
        authorId: authorId,
      );
      return ChatMessage(
        id: id,
        roomId: roomId,
        authorId: authorId,
        plaintext: clear,
        createdAt: createdAt,
        isMine: isMine,
        status: MessageDeliveryStatus.sent,
      );
    } catch (e) {
      return ChatMessage(
        id: id,
        roomId: roomId,
        authorId: authorId,
        plaintext: '[Unable to decrypt message]',
        createdAt: createdAt,
        isMine: isMine,
        status: MessageDeliveryStatus.sent,
        decryptionError: e.toString(),
      );
    }
  }

  Future<void> _subscribeToRoom(String roomId) async {
    final client = SupabaseConfig.client;
    if (client == null) return;

    await _unsubscribeChannel();

    final channel = client.channel('private_room_$roomId');

    channel
        .onPostgresChanges(
          event: PostgresChangeEvent.insert,
          schema: 'public',
          table: 'messages',
          filter: PostgresChangeFilter(
            type: PostgresChangeFilterType.eq,
            column: 'room_id',
            value: roomId,
          ),
          callback: (payload) {
            unawaited(_handleIncomingMessage(payload.newRecord));
          },
        )
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: 'room_members',
          filter: PostgresChangeFilter(
            type: PostgresChangeFilterType.eq,
            column: 'room_id',
            value: roomId,
          ),
          callback: (_) {
            unawaited(_handleMembershipChange(roomId));
          },
        )
        .subscribe((status, error) {
      if (_disposed) return;
      if (status == RealtimeSubscribeStatus.channelError ||
          status == RealtimeSubscribeStatus.timedOut) {
        _connectionStatus = RoomConnectionStatus.offlineError;
        _errorMessage = error?.toString() ??
            'Realtime connection interrupted. Check your internet connection.';
        _safeNotify();
      } else if (status == RealtimeSubscribeStatus.subscribed) {
        if (_session?.hasPeer == true && _sharedKey != null) {
          _connectionStatus = RoomConnectionStatus.connected;
        } else {
          _connectionStatus = RoomConnectionStatus.waitingForPeer;
        }
        _safeNotify();
      }
    });

    _roomChannel = channel;
  }

  Future<void> _handleIncomingMessage(Map<String, dynamic> record) async {
    if (_disposed || record.isEmpty) return;
    final id = record['id'] as String?;
    if (id == null) return;

    if (_messages.any((m) => m.id == id)) return;

    final decrypted = await _decryptRow(record, currentUserId);
    _messages = [..._messages, decrypted];
    _deduplicateMessages();
    _safeNotify();
  }

  Future<void> _handleMembershipChange(String roomId) async {
    if (_disposed) return;
    final current = _session;
    if (current == null || current.roomId != roomId) return;

    try {
      await _restoreServerSession(current);
      _safeNotify();
    } catch (_) {
      // Transient realtime refresh error handled gracefully.
    }
  }

  Future<void> _unsubscribeChannel() async {
    final client = SupabaseConfig.client;
    final channel = _roomChannel;
    _roomChannel = null;
    if (client != null && channel != null) {
      try {
        await client.removeChannel(channel);
      } catch (_) {}
    }
  }

  Future<void> _markMessageFailed(
    String roomId,
    String localId,
    String plaintext,
    DateTime createdAt,
    String reason,
  ) async {
    _messages = _messages.map((m) {
      if (m.id == localId) {
        return m.copyWith(status: MessageDeliveryStatus.failed);
      }
      return m;
    }).toList();
    _errorMessage = reason;

    final existingDrafts = await _securePrefs.getUnsentDrafts(roomId);
    if (!existingDrafts.any((d) => d.localId == localId)) {
      await _securePrefs.saveUnsentDrafts(roomId, [
        ...existingDrafts,
        UnsentMessageDraft(
          localId: localId,
          plaintext: plaintext,
          createdAt: createdAt,
        ),
      ]);
    }
    _safeNotify();
  }

  Future<void> _loadUnsentDrafts(String roomId) async {
    final drafts = await _securePrefs.getUnsentDrafts(roomId);
    if (drafts.isEmpty) return;

    final myId = currentUserId ?? 'local';
    final draftMessages = drafts.map((d) {
      return ChatMessage(
        id: d.localId,
        roomId: roomId,
        authorId: myId,
        plaintext: d.plaintext,
        createdAt: d.createdAt,
        isMine: true,
        status: MessageDeliveryStatus.failed,
      );
    }).toList();

    for (final dm in draftMessages) {
      if (!_messages.any((m) => m.id == dm.id)) {
        _messages = [..._messages, dm];
      }
    }
  }

  Future<void> _removeUnsentDraft(String roomId, String localId) async {
    final drafts = await _securePrefs.getUnsentDrafts(roomId);
    final remaining = drafts.where((d) => d.localId != localId).toList();
    await _securePrefs.saveUnsentDrafts(roomId, remaining);
  }

  void _deduplicateMessages() {
    final seen = <String>{};
    final deduped = <ChatMessage>[];
    for (final msg in _messages) {
      if (seen.add(msg.id)) {
        deduped.add(msg);
      }
    }
    deduped.sort((a, b) => a.createdAt.compareTo(b.createdAt));
    _messages = deduped;
  }

  String _mapFriendlyError(Object error) {
    if (error is PrivateChatException) return error.message;
    if (error is TimeoutException) {
      return 'Request timed out. Check your internet connection and try again.';
    }
    if (error is SocketException) {
      return 'No internet connection. Please check your network and retry.';
    }
    if (error is AuthException) {
      return 'Authentication error: ${error.message}';
    }
    if (error is PostgrestException) {
      final msg = error.message;
      if (msg.contains('INVALID_CODE')) {
        return 'Invalid invitation code. Double-check the code and try again.';
      }
      if (msg.contains('INVITE_ALREADY_USED')) {
        return 'This invitation code has already been used by another participant.';
      }
      if (msg.contains('ROOM_FULL')) {
        return 'This private room already has two participants.';
      }
      if (msg.contains('UNAUTHENTICATED')) {
        return 'Anonymous session expired. Please try again.';
      }
      return 'Server error: $msg';
    }
    return 'Unable to complete operation: $error';
  }

  @override
  void dispose() {
    _disposed = true;
    unawaited(_unsubscribeChannel());
    super.dispose();
  }
}
