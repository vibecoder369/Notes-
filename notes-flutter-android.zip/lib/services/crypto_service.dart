import 'dart:convert';
import 'dart:typed_data';

import 'package:cryptography/cryptography.dart';

class CryptoDecryptionException implements Exception {
  CryptoDecryptionException(this.message);
  final String message;

  @override
  String toString() => message;
}

class GeneratedKeyPair {
  const GeneratedKeyPair({
    required this.privateKeyBase64,
    required this.publicKeyBase64,
  });

  final String privateKeyBase64;
  final String publicKeyBase64;
}

/// Genuine End-to-End Encryption using X25519 key agreement,
/// HKDF-SHA256 key derivation, and AES-256-GCM authenticated encryption.
class CryptoService {
  CryptoService();

  static const String _envelopePrefix = 'v1';
  static const String _kdfInfo = 'notes-e2ee-v1';

  final X25519 _keyExchange = X25519();
  final Hkdf _hkdf = Hkdf(
    hmac: Hmac.sha256(),
    outputLength: 32,
  );
  final AesGcm _aesGcm = AesGcm.with256bits();
  final Sha256 _sha256 = Sha256();

  Future<GeneratedKeyPair> generateKeyPair() async {
    final keyPair = await _keyExchange.newKeyPair();
    final privateBytes = await keyPair.extractPrivateKeyBytes();
    final publicKey = await keyPair.extractPublicKey();

    return GeneratedKeyPair(
      privateKeyBase64: base64Encode(privateBytes),
      publicKeyBase64: base64Encode(publicKey.bytes),
    );
  }

  Future<SecretKey> deriveSharedKey({
    required String myPrivateKeyBase64,
    required String peerPublicKeyBase64,
    required String roomId,
  }) async {
    final privateBytes = base64Decode(myPrivateKeyBase64);
    final peerPublicBytes = base64Decode(peerPublicKeyBase64);

    final myKeyPair = await _keyExchange.newKeyPairFromSeed(privateBytes);
    final peerPublicKey = SimplePublicKey(
      peerPublicBytes,
      type: KeyPairType.x25519,
    );

    final rawSharedSecret = await _keyExchange.sharedSecretKey(
      keyPair: myKeyPair,
      remotePublicKey: peerPublicKey,
    );

    return _hkdf.deriveKey(
      secretKey: rawSharedSecret,
      nonce: utf8.encode(roomId),
      info: utf8.encode(_kdfInfo),
    );
  }

  Future<String> encryptMessage({
    required String plaintext,
    required SecretKey sharedKey,
    required String roomId,
    required String authorId,
  }) async {
    final nonce = _aesGcm.newNonce();
    final aad = utf8.encode('$roomId:$authorId');
    final secretBox = await _aesGcm.encrypt(
      utf8.encode(plaintext),
      secretKey: sharedKey,
      nonce: nonce,
      aad: aad,
    );

    return [
      _envelopePrefix,
      base64Encode(secretBox.nonce),
      base64Encode(secretBox.cipherText),
      base64Encode(secretBox.mac.bytes),
    ].join(':');
  }

  Future<String> decryptMessage({
    required String envelope,
    required SecretKey sharedKey,
    required String roomId,
    required String authorId,
  }) async {
    final parts = envelope.split(':');
    if (parts.length != 4 || parts[0] != _envelopePrefix) {
      throw CryptoDecryptionException(
        'Unsupported or malformed encrypted payload.',
      );
    }

    try {
      final nonce = base64Decode(parts[1]);
      final cipherText = base64Decode(parts[2]);
      final macBytes = base64Decode(parts[3]);
      final aad = utf8.encode('$roomId:$authorId');

      final secretBox = SecretBox(
        cipherText,
        nonce: nonce,
        mac: Mac(macBytes),
      );

      final clearBytes = await _aesGcm.decrypt(
        secretBox,
        secretKey: sharedKey,
        aad: aad,
      );

      return utf8.decode(clearBytes);
    } catch (e) {
      throw CryptoDecryptionException(
        'Unable to decrypt message with current room keys.',
      );
    }
  }

  /// Symmetric fingerprint derived from both participants' public keys
  /// so users can verify key authenticity out-of-band.
  Future<String> computeSafetyFingerprint({
    required String publicKeyA,
    required String publicKeyB,
  }) async {
    final ordered = [publicKeyA.trim(), publicKeyB.trim()]..sort();
    final combined = utf8.encode('${ordered[0]}|${ordered[1]}');
    final digest = await _sha256.hash(combined);
    final bytes = Uint8List.fromList(digest.bytes);

    final groups = <String>[];
    for (var i = 0; i < 12; i += 2) {
      final hi = bytes[i].toRadixString(16).padLeft(2, '0').toUpperCase();
      final lo = bytes[i + 1].toRadixString(16).padLeft(2, '0').toUpperCase();
      groups.add('$hi$lo');
    }
    return groups.join(' ');
  }
}
