import 'package:supabase_flutter/supabase_flutter.dart';

class SupabaseConfig {
  SupabaseConfig._();

  static const String supabaseUrl = String.fromEnvironment('SUPABASE_URL');
  static const String supabaseAnonKey = String.fromEnvironment('SUPABASE_ANON_KEY');

  static bool _initialized = false;
  static String? _initError;

  static bool get isConfigured =>
      supabaseUrl.isNotEmpty &&
      supabaseAnonKey.isNotEmpty &&
      supabaseUrl.startsWith('https://');

  static bool get isInitialized => _initialized;
  static String? get initError => _initError;

  static SupabaseClient? get client {
    if (!_initialized) return null;
    try {
      return Supabase.instance.client;
    } catch (_) {
      return null;
    }
  }

  static Future<void> initializeIfConfigured() async {
    if (!isConfigured) {
      _initialized = false;
      _initError =
          'Backend credentials are not configured in this build. Build with '
          '--dart-define=SUPABASE_URL=... and --dart-define=SUPABASE_ANON_KEY=...';
      return;
    }

    try {
      await Supabase.initialize(
        url: supabaseUrl,
        anonKey: supabaseAnonKey,
        authOptions: const FlutterAuthClientOptions(
          authFlowType: AuthFlowType.pkce,
        ),
      );
      _initialized = true;
      _initError = null;
    } catch (e) {
      _initialized = false;
      _initError = 'Failed to initialize backend client: $e';
    }
  }
}
